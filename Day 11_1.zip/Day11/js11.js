/*for check jquery is attach*/
/*show alert msg*/
$(document).ready(function () {
    $("#id1").click(function () {
        alert("Hello Guys");
        $("#ID").hide(300); /* take 3000 mili second time to hide*/
    });
    $("#id2").attr("disabled",true);
    $("#id1").click(function (){
        if(confirm("Are You Sure..?!?"))
        {
           $("#ID").hide(5000);
           $(this).attr("disabled",true);
           $("#id2").attr("disabled",false);
        }
       });
});

$(document).ready(function (){
    $("#id2").click(function (){
        alert("hiiii");
        $("#ID").show();
    });
        $("#id2").click(function (){
        if(confirm("Are You Sure..?!?"))
        {
           $("#ID").show(5000);
           $(this).attr("disabled",true);
           $("#id1").attr("disabled",false);
        }
       });
});

$(document).ready(function () {
    $("#id3").click(function () {
        alert("Hellow Everyone!!")
    });
    $("#id3").click(function () {
        var PLUS = parseInt($("#ID").css("height"));
        if (PLUS <= 500) {
            PLUS += 200;
            $("#ID").css("height", PLUS);
            $("#ID").css("width", PLUS);
        }
        else {
            alert("M0re then 500px is not possible");
        }
    });
});

$(document).ready(function () {
    $("#id4").click(function () {
        alert("Welcome to Silver Oak");
    });
    $("#id4").click(function () {
        var MINUS = parseInt($("#ID").css("height"));
        if (MINUS <= 20) {
            MINUS -= 10;
            $("#ID").css("height", MINUS);
            $("#ID").css("width", MINUS);
        }
        else {
            alert("Less then 20px is not possible");
        }

    });
});

   $("#id2").click(function (){
    if(confirm("Are You Sure..?!?"))
    {
       $("#ID").show(5000);
       $(this).attr("disabled",true);
       $("#id2").attr("disabled",false);
    }
   });