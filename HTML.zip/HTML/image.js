function chaimg1(){
    document.getElementById("trns1").src="flower_textile_background.jpg"
}

function chaimg2(){
    document.getElementById("trns1").src="orange_flower_background.jpg"

}

function chaimg3(){
    document.getElementById("trns1").src="red_rose_flower.jpg"

}